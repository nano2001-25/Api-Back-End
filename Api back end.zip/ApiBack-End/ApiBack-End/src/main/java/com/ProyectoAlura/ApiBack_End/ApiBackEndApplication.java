package com.ProyectoAlura.ApiBack_End;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiBackEndApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApiBackEndApplication.class, args);
	}

}
