// src/main/java/com/tuempresa/apibackend/service/TopicService.java
package com.tuempresa.apibackend.service;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import com.tuempresa.apibackend.repository.TopicRepository;
import com.tuempresa.apibackend.model.Topic;
import com.tuempresa.apibackend.exception.DuplicateTopicException;

@Service
@RequiredArgsConstructor
public class TopicService {

    private final TopicRepository topicRepository;

    @Transactional
    public Topic createTopic(@Valid Topic topic) {
        // Verificar duplicados (titulo + mensaje)
        boolean exists = topicRepository.findByTituloAndMensaje(topic.getTitulo(), topic.getMensaje()).isPresent();
        if (exists) {
            throw new DuplicateTopicException("Ya existe un tópico con ese título y mensaje.");
        }

        // Configurar campos automáticos si no se han establecido
        if (topic.getFechaCreacion() == null) {
            topic.setFechaCreacion(java.time.LocalDateTime.now());
        }
        if (topic.getStatus() == null) {
            topic.setStatus(com.tuempresa.apibackend.model.TopicStatus.OPEN);
        }

        return topicRepository.save(topic);
    }

    public List<Topic> getAllTopics() {
        return topicRepository.findAll();
    }

    // Puedes añadir métodos de lectura/actualización según necesites
}