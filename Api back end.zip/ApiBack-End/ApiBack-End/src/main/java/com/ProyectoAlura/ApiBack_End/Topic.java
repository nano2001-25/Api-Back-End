// src/main/java/com/tuempresa/apibackend/model/Topic.java
package com.tuempresa.apibackend.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import lombok.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "topics", uniqueConstraints = @UniqueConstraint(columnNames = {"titulo", "mensaje"}))
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Topic {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank
    @Column(nullable = false, length = 255)
    private String titulo;

    @NotBlank
    @Column(nullable = false, columnDefinition = "TEXT")
    private String mensaje;

    @Column(name = "fecha_creacion", nullable = false)
    private LocalDateTime fechaCreacion = LocalDateTime.now();

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    private TopicStatus status = TopicStatus.OPEN;

    @NotBlank
    @Column(nullable = false, length = 100)
    private String autor;

    @NotBlank
    @Column(nullable = false, length = 100)
    private String curso;
}