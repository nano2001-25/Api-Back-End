// src/main/java/com/tuempresa/apibackend/exception/DuplicateTopicException.java
package com.tuempresa.apibackend.exception;

public class DuplicateTopicException extends RuntimeException {
    public DuplicateTopicException(String message) {
        super(message);
    }
}